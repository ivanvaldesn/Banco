document.addEventListener('DOMContentLoaded', function() {
    const menuAuth = document.getElementById('menu-auth');
    const menuLogout = document.getElementById('menu-logout');
    const cerrarSesion = document.getElementById('cerrarSesion');
    let usuarioActual = null;

    function actualizarMenuAutenticacion() {
        if (menuAuth && menuLogout) {
            if (usuarioActual) {
                menuAuth.style.display = 'none';
                menuLogout.style.display = 'inline';
            } else {
                menuAuth.style.display = 'inline';
                menuLogout.style.display = 'none';
            }
        }
    }

    function mostrarSeccion(seccionId) {
        document.querySelectorAll('section').forEach(section => section.style.display = 'none');
        document.getElementById(seccionId).style.display = 'block';
        
        if (seccionId === 'home') {
            actualizarMensajeBienvenida();
        }
        actualizarMenuAutenticacion();
    }

    function actualizarMensajeBienvenida() {
        const bienvenida = document.getElementById('bienvenida');
        const mensajeBienvenida = document.getElementById('mensajeBienvenida');
        const botonIniciarSesion = document.getElementById('botonIniciarSesion');
        
        if (usuarioActual) {
            bienvenida.textContent = `Bienvenido, ${usuarioActual}`;
            mensajeBienvenida.style.display = 'block';
            botonIniciarSesion.style.display = 'none';
            mostrarCuentasUsuario();
        } else {
            bienvenida.textContent = 'Bienvenido a BankNext, por favor inicie sesión o regístrese para proceder';
            mensajeBienvenida.style.display = 'none';
            botonIniciarSesion.style.display = 'block';
            botonIniciarSesion.addEventListener('click', () => {
                mostrarSeccion('login');
            });
        }
    }

    cerrarSesion.addEventListener('click', async () => {
        try {
            const response = await fetch('http://localhost:3000/logout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const result = await response.json();
            if (result.success) {
                usuarioActual = null;
                actualizarMensajeBienvenida();
                mostrarSeccion('home');
            } else {
                mostrarMensaje('error', 'Error al cerrar sesión');
            }
        } catch (error) {
            mostrarMensaje('error', 'Error al cerrar sesión');
        }
    });

    async function obtenerCuentas() {
        if (!usuarioActual) return;

        try {
            const response = await fetch(`http://localhost:3000/api/cuentas/${usuarioActual}`);
            const result = await response.json();
            if (result.success) {
                mostrarCuentas(result.cuentas);
            } else {
                mostrarMensaje('error', 'Error al obtener las cuentas');
            }
        } catch (error) {
            mostrarMensaje('error', 'Error al obtener las cuentas');
        }
    }

    async function mostrarCuentasUsuario() {
        if (!usuarioActual) return;

        try {
            const response = await fetch('http://localhost:3000/api/cuentas', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username: usuarioActual })
            });

            const cuentas = await response.json();
            const cuentasContainer = document.getElementById('cuentasContainer');
            cuentasContainer.innerHTML = '';

            if (cuentas.length === 0) {
                cuentasContainer.innerHTML = `<button id="crearCuentaBtn">Crear Cuenta</button>`;
                document.getElementById('crearCuentaBtn').addEventListener('click', () => {
                    mostrarSeccion('cuentas');
                });
            } else {
                cuentasContainer.innerHTML = `<h2>Cuentas</h2> <br> <br>`;
                cuentas.forEach(cuenta => {
                    const cuentaDiv = document.createElement('div');
                    cuentaDiv.className = 'cuenta';
                    cuentaDiv.innerHTML = `
                        <h3>Cuenta ${cuenta.tipoCuenta}</h3>
                        <p>ID: ${cuenta.id}</p>
                        <p>Saldo: ${cuenta.saldo}</p>
                        <p>Estado: ${cuenta.estado}</p>
                    `;
                    cuentasContainer.appendChild(cuentaDiv);
                });
                const crearCuentaDiv = document.createElement('div');
                crearCuentaDiv.className = 'cuenta';
                crearCuentaDiv.innerHTML = `<button id="crearCuentaBtn">Crear Cuenta</button>`;
                cuentasContainer.appendChild(crearCuentaDiv);
                document.getElementById('crearCuentaBtn').addEventListener('click', () => {
                    mostrarSeccion('cuentas');
                });
            }
        } catch (error) {
            mostrarMensaje('error', 'Error al cargar las cuentas del usuario');
        }
    }

    async function crearCuenta(nombreUsuario, tipoCuenta) {
        try {
            const response = await fetch('http://localhost:3000/api/cuentas', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ nombreUsuario, tipoCuenta })
            });
            const result = await response.json();
            if (result.success) {
                mostrarMensaje('success', 'Cuenta creada exitosamente');
                obtenerCuentas();
            } else {
                mostrarMensaje('error', 'Error al crear la cuenta');
            }
        } catch (error) {
            mostrarMensaje('error', 'Error al crear la cuenta');
        }
    }

    // Inicializa page.js
    page('/', () => mostrarSeccion('home'));
    page('/cuentas', () => mostrarSeccion('cuentas'));
    page('/transacciones', () => mostrarSeccion('transacciones'));
    page('/reportes', () => mostrarSeccion('reportes'));
    page('/estadoCuenta', () => mostrarSeccion('estadoCuenta'));
    page('/login', () => mostrarSeccion('login'));
    page('/registro', () => mostrarSeccion('registro'));
    page('/crearCuenta', () => mostrarSeccion('crearCuenta'));
    page('/politicas', () => mostrarSeccion('politicas'));
    page();
    
    const asignarCuentaForm = document.getElementById('asignarCuentaForm');
    const transaccionForm = document.getElementById('transaccionForm');
    const generarReporteButton = document.getElementById('generarReporte');
    const reporteResultado = document.getElementById('reporteResultado');
    const estadoCuentaForm = document.getElementById('estadoCuentaForm');
    const estadoCuentaResultado = document.getElementById('estadoCuentaResultado');
    const loginForm = document.getElementById('loginForm');
    const registroForm = document.getElementById('registroForm');
    const mensajeDiv = document.getElementById('mensaje');

    function mostrarMensaje(tipo, texto) {
        mensajeDiv.className = tipo;
        mensajeDiv.textContent = texto;
        mensajeDiv.style.display = 'block';
        setTimeout(() => {
            mensajeDiv.style.display = 'none';
        }, 3000);
    }

    registroForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const newUsername = event.target.newUsername.value;
        const newPassword = event.target.newPassword.value;

        fetch('http://localhost:3000/api/registro', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: newUsername, password: newPassword })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al registrar usuario');
            }
            return response.text();
        })
        .then(data => {
            mostrarMensaje('success', data);
            usuarioActual = newUsername;
            actualizarMensajeBienvenida();
            page.redirect('/');
        })
        .catch(error => {
            mostrarMensaje('error', error.message);
        });

        registroForm.reset();
    });

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = event.target.username.value;
        const password = event.target.password.value;

        fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Usuario o contraseña incorrectos');
            }
            return response.text();
        })
        .then(data => {
            mostrarMensaje('success', data);
            usuarioActual = username;
            actualizarMensajeBienvenida();
            page.redirect('/');
        })
        .catch(error => {
            mostrarMensaje('error', error.message);
        });

        loginForm.reset();
    });

    asignarCuentaForm.addEventListener('submit', function(event) {
        event.preventDefault();
        if (!usuarioActual) {
            mostrarMensaje('error', 'Debe iniciar sesión para asignar una cuenta');
            return;
        }

        const tipoCuenta = event.target.tipoCuenta.value;

        fetch('http://localhost:3000/api/asignarCuenta', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nombreUsuario: usuarioActual, tipoCuenta })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al asignar cuenta');
            }
            return response.text();
        })
        .then(data => {
            mostrarMensaje('success', data);
        })
        .catch(error => {
            mostrarMensaje('error', error.message);
        });

        asignarCuentaForm.reset();
    });

    transaccionForm.addEventListener('submit', function(event) {
        event.preventDefault();
        if (!usuarioActual) {
            mostrarMensaje('error', 'Debe iniciar sesión para realizar una transacción');
            return;
        }

        const cuentaID = event.target.cuentaID.value;
        const tipoTransaccion = event.target.tipoTransaccion.value;
        const monto = parseFloat(event.target.monto.value);
        const moneda = event.target.moneda.value;

        fetch('http://localhost:3000/api/transaccion', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cuentaID, tipoTransaccion, monto, moneda })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al realizar transacción');
            }
            return response.text();
        })
        .then(data => {
            mostrarMensaje('success', data);
        })
        .catch(error => {
            mostrarMensaje('error', error.message);
        });

        transaccionForm.reset();
    });

    generarReporteButton.addEventListener('click', async function() {
        try {
            const response = await fetch('http://localhost:3000/api/reporte', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
    
            const reporte = await response.json();
            if (reporte.error) {
                mostrarMensaje('error', 'Error al generar el reporte');
            } else {
                let reporteHTML = `<h3>Reporte Diario - ${new Date().toLocaleDateString()}</h3>`;
                reporteHTML += `<ul>`;
                reporte.transacciones.forEach(transaccion => {
                    const monto = parseFloat(transaccion.monto) - (transaccion.comision ? parseFloat(transaccion.comision) : 0);
                    let comisionTexto = transaccion.comision ? ` (Comisión: ${transaccion.comision})` : '';
                    reporteHTML += `<li>${transaccion.tipoTransaccion} de ${monto} en cuenta ${transaccion.cuentaID}${comisionTexto}</li>`;
                });
                reporteHTML += `</ul>`;
                reporteResultado.innerHTML = reporteHTML;
            }
        } catch (error) {
            mostrarMensaje('error', 'Error al generar el reporte');
        }
    });
    
    document.getElementById('cerrarSesionBtn').addEventListener('click', () => {
        usuarioActual = null;
        actualizarMensajeBienvenida();
        page.redirect('/');
    });




    function convertirAMonedaLocal(monto, moneda) {
        switch (moneda) {
            case 'dolares':
                return monto * 3800;
            case 'euros':
                return monto * 4300;
            case 'pesos':
            default:
                return monto;
        }
    }

    function obtenerFechaActual() {
        const fecha = new Date();
        return fecha.toISOString().split('T')[0]; // Retorna solo la fecha en formato YYYY-MM-DD
    }

    // Ejecutar comisiones mensuales e intereses diarios
    setInterval(ejecutarComisiones, 24 * 60 * 60 * 1000); // Se ejecuta una vez al día
    setInterval(asignarInteresDiario, 24 * 60 * 60 * 1000); // Se ejecuta una vez al día
});
