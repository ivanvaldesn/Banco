import express from 'express';
import bodyParser from 'body-parser';
import mysql from 'mysql2';
import cors from 'cors';

// Configura la conexión a la base de datos MySQL
const pool = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: '',
    database: 'banco_db'
}).promise();

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/logout', (req, res) => {
    res.clearCookie('session');
    res.json({ success: true });
});

// Ruta para registrar un nuevo usuario
app.post('/api/registro', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await pool.query('SELECT * FROM usuarios WHERE username = ?', [username]);
        if (rows.length > 0) {
            return res.status(400).send('Usuario ya existe');
        }

        await pool.query('INSERT INTO usuarios (username, password) VALUES (?, ?)', [username, password]);
        res.status(201).send('Usuario registrado exitosamente');
    } catch (error) {
        console.error('Error al registrar usuario:', error);
        res.status(500).send('Error al registrar usuario');
    }
});

// Ruta para iniciar sesión
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await pool.query('SELECT * FROM usuarios WHERE username = ? AND password = ?', [username, password]);
        if (rows.length === 0) {
            return res.status(401).send('Usuario o contraseña incorrectos');
        }
        res.status(200).send('Inicio de sesión exitoso');
    } catch (error) {
        console.error('Error al iniciar sesión:', error);
        res.status(500).send('Error al iniciar sesión');
    }
});

// Obtener cuentas del usuario
app.post('/api/cuentas', async (req, res) => {
    const { username } = req.body;
    try {
        const [rows] = await pool.query('SELECT * FROM cuentas WHERE nombreUsuario = ?', [username]);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Asignar cuenta a usuario
app.post('/api/asignarCuenta', async (req, res) => {
    const { nombreUsuario, tipoCuenta } = req.body;
    try {
        await pool.query('INSERT INTO cuentas (nombreUsuario, tipoCuenta) VALUES (?, ?)', [nombreUsuario, tipoCuenta]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Ruta para crear una nueva cuenta
app.post('/api/cuentas', async (req, res) => {
    const { nombreUsuario, tipoCuenta } = req.body;
    try {
        const [rows] = await pool.query('INSERT INTO cuentas (nombreUsuario, tipoCuenta) VALUES (?, ?)', [nombreUsuario, tipoCuenta]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Error al crear la cuenta' });
    }
});

// Ruta para realizar una transacción
app.post('/api/transaccion', async (req, res) => {
    const { cuentaID, tipoTransaccion, monto, moneda } = req.body;
    try {
        const [cuentaRows] = await pool.query('SELECT * FROM cuentas WHERE id = ?', [cuentaID]);
        if (cuentaRows.length === 0) {
            return res.status(404).send('Cuenta no encontrada');
        }

        let montoEnPesos = parseFloat(monto);
        if (moneda === 'dolares') montoEnPesos = montoEnPesos * 3800;
        if (moneda === 'euros') montoEnPesos = montoEnPesos * 4300;

        let saldoActual = parseFloat(cuentaRows[0].saldo);
        let comision = 0;

        if (tipoTransaccion === 'ingreso') {
            comision = montoEnPesos > 50000 ? montoEnPesos * 0.01 : 100;
            saldoActual += (montoEnPesos - comision);
        } else if (tipoTransaccion === 'retiro') {
            comision = montoEnPesos > 50000 ? montoEnPesos * 0.01 : 100;
            if (saldoActual < (montoEnPesos + comision)) {
                return res.status(400).send('Saldo insuficiente');
            }
            saldoActual -= (montoEnPesos + comision);
        } else {
            return res.status(400).send('Tipo de transacción no válido');
        }

        await pool.query('UPDATE cuentas SET saldo = ? WHERE id = ?', [saldoActual, cuentaID]);
        await pool.query('INSERT INTO transacciones (cuentaID, tipoTransaccion, monto, moneda) VALUES (?, ?, ?, ?)', [cuentaID, tipoTransaccion, montoEnPesos, moneda]);

        res.status(201).send('Transacción realizada exitosamente');
    } catch (error) {
        console.error('Error al realizar transacción:', error);
        res.status(500).send('Error al realizar transacción');
    }
});

// Ruta para generar el reporte diario
app.get('/api/reporte', async (req, res) => {
    try {
        const [transacciones] = await pool.query('SELECT * FROM transacciones WHERE DATE(fecha) = CURDATE()');
        res.json({ transacciones });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});
